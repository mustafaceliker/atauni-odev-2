# MUSTAFA BERKE CELIKER - 210707089 hwork1
# script bir file_input isimli dosyayı input  alarak önce bilgilerini (perm vs.) kontrol edecek.
# daha sonrasında bunları chmod vs. ile değiştirmeye çalışacak.

# önce  kullanım var mı diye kontrol ediyoruz. bu sayede yanlış veya fazla argüman verildiğinde script çalışmayacaktır ve doğru kullanımı kullanıcıya gösterecektir.

if [ "$#" -ne 1 ]; then
	echo "Kullanım: $0 <input_file>"
	exit 1
fi

input_file="$1"

# input file'ın bilgilerini okuyacağız.

read -p "Dosya sahibini girin:" file_owner
read -p "Dosya grubunu girin: " file_group
read -p "Dosya izinlerini girin (örnek:575): " file_perms

# input file'ın bilgileri read ile okunduktan sonra chmod ve chown ile istenilen değişiklikler (owner-group-perms) yapılacak.

chmod "$file_perms" "$input_file"
chown "$file_owner:$file_group" "$input_file"

echo "Dosyadaki değişiklikler başarıyla güncellendi!"
